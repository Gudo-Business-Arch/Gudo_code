from google_images_search import GoogleImagesSearch
from dotenv import load_dotenv
import os

# you can provide API key and CX using arguments,
# or you can set environment variables: GCS_DEVELOPER_KEY, GCS_CX
# API KEY AND CX
gis = GoogleImagesSearch(
    'AIzaSyCCzauT31U9L8DYNPlOf6diUcO37uAVU7g', '91e41b14254e94cda')

if os.path.exists(".env"):
    load_dotenv()
else:
    print(".env file missing, please create one with your API and CX")

if not os.path.exists('images/'):
    os.mkdir('images/')
spath = 'images/'

# env variables
DK = os.environ.get('AIzaSyCCzauT31U9L8DYNPlOf6diUcO37uAVU7g')
CX = os.environ.get('91e41b14254e94cda')

# custom progressbar function


def my_progressbar(url, progress):
    print(url + " " + progress + "%")


# create google images search - object
gis = GoogleImagesSearch(DK, CX, progressbar_fn=my_progressbar)


def fetch_images(searchfor):
    # using contextual mode (Curses)
    with GoogleImagesSearch(DK, CX) as gis:
        # define search params:
        _search_params = {"q": searchfor,
                          "num": 1,
                          "safe": "high",
                          "fileType": "jpg",
                          "imgType": "photo",
                          "rights": "cc_publicdomain"
                          #  free for use by anyone for any purpose without restriction under copyright law
                          }
        gis.search(search_params=_search_params, path_to_dir=spath)

    print("Finished!")

# # define search params:
# _search_params = {
#     'q': '...',
#     'num': 1,
#     'safe': 'high|medium|off',
#     'fileType': 'jpg|gif|png',
#     'imgType': 'clipart|face|lineart|news|photo',
#     'imgSize': 'huge|icon|large|medium|small|xlarge|xxlarge',
#     'imgDominantColor': 'black|blue|brown|gray|green|orange|pink|purple|red|teal|white|yellow',
#     'imgColorType': 'color|gray|mono|trans',
#     'rights': 'cc_publicdomain|cc_attribute|cc_sharealike|cc_noncommercial|cc_nonderived'
# }

# # this will only search for images:
# gis.search(search_params=_search_params)

# # this will search and download:
# gis.search(search_params=_search_params, path_to_dir='/path/')

# # this will search, download and resize:
# gis.search(search_params=_search_params, path_to_dir='/path/', width=500, height=500)

# # search first, then download and resize afterwards:
# gis.search(search_params=_search_params)
# for image in gis.results():
#     image.download('/path/')
#     image.resize(500, 500)
